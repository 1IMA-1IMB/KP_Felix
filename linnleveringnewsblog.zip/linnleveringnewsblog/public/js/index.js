function log() {
    console.log('Hello world')
}